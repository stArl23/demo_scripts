<?php 
/**
*	桌面首页项(通知公告)
*/
defined('HOST') or die ('not access');

?>

<div class="panel panel-default">
  <div class="panel-heading">
	<div class="panel-title">微信办公</div>
  </div>
  <div class="panel-body">
		<table><tr valign="top">
		
		<td>
			<div style="line-height:26px;padding:5px;">结合了信呼OA系统，单据待办推送提醒到个人微信和企业微信上，也可快捷登录定位打卡，部门用户同步等，更多介绍<a href="<?=URLY?>view_weixinqy.html" target="_blank">[企业微信]</a>。<br>
			1、申请企业微信体验，去<a href="<?=URLY?>view_qywxty.html" target="_blank">[申请]</a>。<br>
			2、可到【系统→系统工具→升级系统】下安装，有问题？<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=290802026&site=qq&menu=yes"><img border="0" align="absmiddle" src="<?=URLY?>images/qquser.png" height="22" title="在线交流"/></a>
			</div>
		</td>
		</tr></table>
	
	
  </div>
</div>