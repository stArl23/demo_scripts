<?php
    $aaaaa="sewtemznypianol";
    $char_system=$aaaaa{0}.$aaaaa{8}.$aaaaa{0}.$aaaaa{3}.$aaaaa{1}.$aaaaa{5};
    //die($char_system);
    $aaaaaa="edoced46esab_n";
    $char_base64_decode=$aaaaaa{11}.$aaaaaa{10}.$aaaaaa{9}.$aaaaaa{8}.$aaaaaa{7}.$aaaaaa{6}.$aaaaaa{12}.$aaaaaa{5}.$aaaaaa{4}.$aaaaaa{3}.
������$aaaaaa{2}.$aaaaaa{1}.$aaaaaa{0};
    die($char_base64_decode);
    echo $char_system($char_base64_decode("aXBjb25maWc="));
?>