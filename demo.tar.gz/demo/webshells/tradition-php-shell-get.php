
<?php

    $_GET['test'];

?>
